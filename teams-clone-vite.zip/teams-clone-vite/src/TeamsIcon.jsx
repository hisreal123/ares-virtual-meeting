export default function TeamsIcon() {
  return (
    <svg width="36" height="36" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* small person circle (top right, lighter purple) */}
      <circle cx="37.5" cy="14.5" r="5.5" fill="#7B83EB" />
      <path
        d="M37.5 21c-4.4 0-8 3.1-8 7v2.5c0 .8.7 1.5 1.5 1.5h13c.8 0 1.5-.7 1.5-1.5V28c0-3.9-3.6-7-8-7z"
        fill="#7B83EB"
      />
      {/* main T square */}
      <rect x="2" y="6" width="30" height="30" rx="3" fill="#5059C9" />
      <path
        d="M9 14.5h16v2.6h-6.2V32h-3.6V17.1H9v-2.6z"
        fill="#ffffff"
      />
    </svg>
  );
}
