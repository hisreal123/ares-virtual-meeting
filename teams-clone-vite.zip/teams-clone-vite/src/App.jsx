import { useState } from 'react';
import TeamsIcon from './TeamsIcon';
import './App.css';

function CameraOffIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M2.75 4.75L21.25 21.25"
        stroke="#424242"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
      <path
        d="M15 8h1.5A1.5 1.5 0 0118 9.5v5A1.5 1.5 0 0116.5 16H6.62M4.5 8H15v6.88"
        stroke="#424242"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      <path
        d="M18.5 10.3l3.02-1.74a.6.6 0 01.9.52v5.84a.6.6 0 01-.9.52L18.5 13.7"
        stroke="#424242"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  );
}

function CamOffSmallIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M2.75 4.75L21.25 21.25" stroke="#D13438" strokeWidth="1.6" strokeLinecap="round" />
      <path
        d="M15 8h1.5A1.5 1.5 0 0118 9.5v5A1.5 1.5 0 0116.5 16H6.62M4.5 8H15v6.88"
        stroke="#D13438"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      <path
        d="M18.5 10.3l3.02-1.74a.6.6 0 01.9.52v5.84a.6.6 0 01-.9.52L18.5 13.7"
        stroke="#D13438"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  );
}

function BackgroundFiltersIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="7" cy="7" r="2.4" stroke="#BDBDBD" strokeWidth="1.3" />
      <circle cx="12" cy="15" r="2.4" stroke="#BDBDBD" strokeWidth="1.3" />
      <circle cx="17" cy="8" r="2.4" stroke="#BDBDBD" strokeWidth="1.3" />
    </svg>
  );
}

function MicOffIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M3 3.5L21 21" stroke="#D13438" strokeWidth="1.6" strokeLinecap="round" />
      <path
        d="M15.5 11V6.5a3.5 3.5 0 00-6.66-1.53M9 9.7V11a3.5 3.5 0 005.06 3.13"
        stroke="#D13438"
        strokeWidth="1.6"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M6 11a6 6 0 006 6m6-6a6 6 0 01-1.2 3.6M12 17v3m-3 0h6"
        stroke="#D13438"
        strokeWidth="1.6"
        strokeLinecap="round"
        fill="none"
      />
    </svg>
  );
}

function SpeakerIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M4 9.5v5h3.2L12 18.2V5.8L7.2 9.5H4z"
        fill="#BDBDBD"
      />
      <path
        d="M15.5 9a4 4 0 010 6"
        stroke="#BDBDBD"
        strokeWidth="1.4"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M17.5 6.5a7.5 7.5 0 010 11"
        stroke="#BDBDBD"
        strokeWidth="1.4"
        strokeLinecap="round"
        fill="none"
      />
    </svg>
  );
}

function Chevron() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function CamToggleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M3 3.5L21 21" stroke="#D13438" strokeWidth="1.6" strokeLinecap="round" />
      <path
        d="M15 7.5h1.6A1.4 1.4 0 0118 8.9v6.2a1.4 1.4 0 01-1.4 1.4h-9M4.5 7.5H15v9.4"
        stroke="#D13438"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      <path
        d="M18.5 10.2l3-1.7a.55.55 0 01.8.48v5.6a.55.55 0 01-.8.48l-3-1.7"
        stroke="#D13438"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  );
}

function CloseIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M5 5l14 14M19 5L5 19" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

export default function App() {
  const [micToggle, setMicToggle] = useState(true);
  const [audioOption, setAudioOption] = useState('computer');
  const [showPopup, setShowPopup] = useState(true);

  return (
    <div className="page">
      <div className="header">
        <TeamsIcon />
        <h1>Microsoft Teams meeting</h1>
      </div>

      <div className="panels">
        {/* Left: video preview panel */}
        <div className="panel video-panel">
          <div className="video-preview">
            <CameraOffIcon />
            <span className="video-off-text">Your camera is turned off</span>
          </div>
          <div className="video-toolbar">
            <div className="cam-toggle-group">
              <CamOffSmallIcon />
              <span className="dropdown-chevron"><Chevron /></span>
            </div>
            <label className="switch">
              <input type="checkbox" />
              <span className="slider" />
            </label>
            <div className="bg-filters">
              <BackgroundFiltersIcon />
              <span>Background filters</span>
            </div>
          </div>
        </div>

        {/* Right: audio options panel */}
        <div className="panel audio-panel">
          <button
            className="audio-row top-row"
            onClick={() => setAudioOption('computer')}
          >
            <span className={`radio ${audioOption === 'computer' ? 'radio-selected' : ''}`} />
            <span className="row-label bold">Computer audio</span>
          </button>

          <div className="mic-speaker-block">
            <div className="sub-row">
              <MicOffIcon />
              <span className="sub-label">None</span>
              <Chevron />
              <label className="switch small-switch">
                <input
                  type="checkbox"
                  checked={micToggle}
                  onChange={() => setMicToggle(!micToggle)}
                />
                <span className="slider" />
              </label>
            </div>
            <div className="sub-row">
              <SpeakerIcon />
              <span className="sub-label">None</span>
              <Chevron />
            </div>
          </div>

          <button
            className="audio-row disabled-row"
            disabled
          >
            <span className="radio" />
            <span className="row-label">Phone audio</span>
          </button>

          <button
            className="audio-row"
            onClick={() => setAudioOption('none')}
          >
            <span className={`radio ${audioOption === 'none' ? 'radio-selected' : ''}`} />
            <span className="row-label bold">Don't use audio</span>
          </button>

          {showPopup && (
            <div className="mic-popup">
              <div className="popup-arrow" />
              <div className="popup-header">
                <h3>Allow Teams to access your mic</h3>
                <button className="popup-close" onClick={() => setShowPopup(false)} aria-label="Close">
                  <CloseIcon />
                </button>
              </div>
              <p>
                Teams needs permission to access your device. Go to your privacy settings to allow
                it, then close this window and join again.
              </p>
              <button className="privacy-btn">Open privacy settings</button>
            </div>
          )}
        </div>
      </div>

      <div className="actions">
        <button className="btn btn-cancel">Cancel</button>
        <button className="btn btn-join">Join now</button>
      </div>

      <div className="footer">
        <a href="#help">Need help?</a>
      </div>
    </div>
  );
}
